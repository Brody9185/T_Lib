#pragma once

// --- Standard Library Includes ---
#include <cstdlib>		// For std::abs
#include <vector>		// For std::vector
#include <memory>		// For std::shared_ptr, std::make_shared
#include <algorithm>	// For std::any_of, std::all_of

// --- PROS/VEX Library Includes ---
#include "pros/misc.h"	// For pros::v5::MotorBrake, etc.
#include "main.h"		// General project header (assuming it defines Aliases)

// --- Local Library Includes ---
#include "T_Lib/Motor.hpp" // T_Motor class definition

using namespace T_Lib;

/**
 * @brief Manages a collection of T_Motor objects, providing a unified interface
 * for setting control parameters (RPM, Brake Mode, PID constants) across all motors simultaneously.
 * * Uses std::shared_ptr for robust memory management of the T_Motor objects.
 */
class T_MotorGroup {
private:
    std::vector<std::shared_ptr<T_Motor>> motors;

    // Conversion helpers
    static std::vector<std::shared_ptr<T_Motor>> convertRawPtrs(const std::vector<T_Motor*>& rawPtrs);
    static std::vector<std::shared_ptr<T_Motor>> convertRawPtrs(std::initializer_list<T_Motor*> rawPtrs);
    static std::vector<std::shared_ptr<T_Motor>> convertObjs(const std::vector<T_Motor>& objs);
    static std::vector<std::shared_ptr<T_Motor>> convertObjs(std::initializer_list<T_Motor> objs);

public:
    // Constructors
    explicit T_MotorGroup(std::initializer_list<std::shared_ptr<T_Motor>> list);
    explicit T_MotorGroup(const std::vector<std::shared_ptr<T_Motor>>& list);
    explicit T_MotorGroup(std::vector<std::shared_ptr<T_Motor>>&& list);
    explicit T_MotorGroup(std::initializer_list<T_Motor*> list);
    explicit T_MotorGroup(const std::vector<T_Motor*>& list);
    explicit T_MotorGroup(std::initializer_list<T_Motor> list);
    explicit T_MotorGroup(const std::vector<T_Motor>& list);

    explicit T_MotorGroup(std::initializer_list<int> ports, pros::v5::MotorGears gearset = util::Aliases::Blue);
    explicit T_MotorGroup(const std::vector<int>& ports, pros::v5::MotorGears gearset = util::Aliases::Blue);

    // Core control
    void setTargetRPM(double rpm);
    void setTargetPercent(double percent);
    void stop();
    void resetPositions();
    void setBrakeMode(pros::v5::MotorBrake mode);

    // Torque and compensation
    void setMinTorque(bool enabled);
    void setMinTorque(bool enabled, int minMv);
    void setMinTorque(bool enabled, int minMv, int minLowMv);
    void setLoadCompensation(bool enabled);
    void setLoadCompensation(bool enabled, double kBoost);
    void setLoadCompensation(bool enabled, double kBoost, int threshold);

    // PID constants
    void setDualConstants(double kvLow, double kpLow, double kvHigh, double kpHigh);
    void setDualConstants(double kvLow, double kpLow, double kiLow, double kdLow, double kvHigh, double kpHigh, double kiHigh, double kdHigh);
    void setLowConstants(double kvLow, double kpLow);
    void setLowConstants(double kvLow, double kpLow, double kiLow, double kdLow);
    void setHighConstants(double kvHigh, double kpHigh);
    void setHighConstants(double kvHigh, double kpHigh, double kiHigh, double kdHigh);
    void setStartI(double startIntegral);

    // Slew control
    void setSlewLimitEnabled(bool SlewOn);
    void setSlewRate(double Slew);

    // PID enable control
    void setPIDEnabled(bool enabled);
    bool isAnyPIDEnabled() const;
    bool areAllPIDEnabled() const;

    // Telemetry & status
    double getAverageRPM() const;
    bool isAnySpinning() const;
    const std::vector<std::shared_ptr<T_Motor>>& getMotors() const;
    size_t size() const;
};