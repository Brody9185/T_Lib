#pragma once

// =========================================================================
// 		 📦 T_Lib API Aggregation Header (api.hpp)
// -------------------------------------------------------------------------
// Provides a unified, single-file interface to access all core components 
// of the T_Lib custom robotics library.
// =========================================================================

/// @file api.hpp
/// @brief Central include file for the T_Lib library.

// === Core Utility and Math Components ===

/**
 * @brief Includes general utilities, constants (Wheel_Size), aliases (Aliases),
 * and unit conversion functions.
 * Also defines the T_Lib::util::units::Percentage type.
 */
#include "T_Lib/util.hpp" 

// === Hardware Abstraction Layer (HAL) Components ===

/**
 * @brief Includes the T_Motor class.
 * Provides custom, task-based control (PID, slew, anti-stall) for a single V5 motor.
 */
#include "T_Lib/Motor.hpp"

/**
 * @brief Includes the T_MotorGroup class.
 * Provides a unified interface to control a collection of T_Motor objects.
 */
#include "T_Lib/Motor_Group.hpp"


// === Advanced Control / Autonomous Components ===

/**
 * @brief Placeholder for an Autonomous Route Calculation system.
 * This is currently commented out, meaning the feature is either disabled, 
 * under development, or not required for the current build.
 */
//#include "T_Lib/AutoRouteCalc.hpp"


// === Global Scope Imports ===

/**
 * @brief Imports the custom C++ user-defined literal operator `_perc` 
 * (e.g., `50_perc`) into the current scope (global scope after this header is included).
 * This allows user code to write percentages concisely.
 */
using T_Lib::util::units::percentage_literals::operator"" _perc;