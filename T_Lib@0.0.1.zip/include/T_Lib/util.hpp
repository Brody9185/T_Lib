#pragma once

// --- PROS Library Includes ---
#include "pros/abstract_motor.hpp" // For motor brake/gearset enums
#include "pros/motors.hpp"		   // For motor brake/gearset enums (redundant, but safe)

// --- Standard Library Includes ---
#include <algorithm> // For std::clamp
#include <cmath>     // For mathematical constants (e.g., PI if not defined)

// Define PI if not available elsewhere, using high precision
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

namespace T_Lib {
namespace util {

// =========================================================================
// ## Wheel_Size 📏
// Contains actual measured diameters for common VEX wheel types (in inches).
// =========================================================================
namespace Wheel_Size {
	/// 4-inch class wheels (actual measured diameters in inches)
	inline constexpr double Omni_4in 		= 4.20070012; 	///< Measured diameter of 4" Omni wheel.
	inline constexpr double Trac_4in 		= 4.000; 		///< Measured diameter of 4" Traction wheel.
	inline constexpr double Trac_Flex_4in 	= 4.000; 		///< Measured diameter of 4" Flex Traction wheel.
	inline constexpr double Mech_4in 		= 4.000; 		///< Measured diameter of 4" Mecanum wheel.

	/// 3.25-inch class wheels (actual measured diameters in inches)
	inline constexpr double Omni_325in 	= 3.250; 		///< Measured diameter of 3.25" Omni wheel.
	inline constexpr double Trac_325in 	= 3.250; 		///< Measured diameter of 3.25" Traction wheel.

	/// 3-inch class wheels (actual measured diameters in inches)
	inline constexpr double Trac_Flex_3in 	= 3.000; 		///< Measured diameter of 3" Flex Traction wheel.
	inline constexpr double Omni_275 		= 2.8545712802768; 		///< Measured diameter of 2.75" Omni wheel.
	inline constexpr double Trac_275 		= 2.750; 		///< Measured diameter of 2.75" Traction wheel.

	/// 2-inch class wheels (actual measured diameters in inches)
	inline constexpr double Omni_2 		= 2.031548819; 	///< Measured diameter of 2" Omni wheel.
	inline constexpr double Trac_2 		= 2.000; 		///< Measured diameter of 2" Traction wheel.
	inline constexpr double Trac_Flex_2 	= 2.000; 		///< Measured diameter of 2" Flex Traction wheel.
	inline constexpr double Mech_2 		= 2.000; 		///< Measured diameter of 2" Mecanum wheel.

	/// Specialty sizes (actual measured diameters in inches)
	inline constexpr double Trac_Flex_1625in = 1.625; 	///< Measured diameter of 1.625" Flex Traction wheel.
}

// -------------------------------------------------------------------------

// =========================================================================
// ## Aliases ⚙️
// Contains convenient, abbreviated aliases for common PROS/VEX enumerations.
// =========================================================================
namespace Aliases {
	// Motor Gearset Aliases
	inline constexpr pros::v5::MotorGears Blue 	= pros::v5::MotorGears::blue; 	///< 600 RPM gearset.
	inline constexpr pros::v5::MotorGears Green = pros::v5::MotorGears::green; 	///< 200 RPM gearset.
	inline constexpr pros::v5::MotorGears Red 	= pros::v5::MotorGears::red; 	///< 100 RPM gearset.
	
	// Motor Encoder Units Aliases
	inline constexpr pros::v5::MotorEncoderUnits Counts 	= pros::v5::MotorEncoderUnits::counts; 	///< Encoder units in raw counts.
	inline constexpr pros::v5::MotorEncoderUnits Degrees 	= pros::v5::MotorEncoderUnits::degrees; ///< Encoder units in degrees (0-360).
	inline constexpr pros::v5::MotorEncoderUnits Rotations 	= pros::v5::MotorEncoderUnits::rotations; ///< Encoder units in rotations.
	
	// Motor Brake Mode Aliases
	inline constexpr pros::v5::MotorBrake Hold 	= pros::v5::MotorBrake::hold; 	///< Brake mode: applies power to actively resist movement.
	inline constexpr pros::v5::MotorBrake Brake = pros::v5::MotorBrake::brake; 	///< Brake mode: shorts the motor terminals (passive brake).
	inline constexpr pros::v5::MotorBrake Coast = pros::v5::MotorBrake::coast; 	///< Brake mode: motors spin freely.
}

// -------------------------------------------------------------------------

// =========================================================================
// ## unitConversion ↔️
// Contains helper functions for converting between common distance and angle units.
// =========================================================================
namespace unitConversion {
	/**
	 * @brief Converts a value from inches to millimeters.
	 * @param inches The distance in inches.
	 * @return The equivalent distance in millimeters.
	 */
	inline double inches_to_mm(double inches) {
		return inches * 25.4;
	}

	/**
	 * @brief Converts a value from millimeters to inches.
	 * @param mm The distance in millimeters.
	 * @return The equivalent distance in inches.
	 */
	inline double mm_to_inches(double mm) {
		return mm / 25.4;
	}

	/**
	 * @brief Converts an angle from degrees to radians.
	 * @param degrees The angle in degrees.
	 * @return The equivalent angle in radians.
	 */
	inline double degrees_to_radians(double degrees) {
		return degrees * (M_PI / 180.0);
	}

	/**
	 * @brief Converts an angle from radians to degrees.
	 * @param radians The angle in radians.
	 * @return The equivalent angle in degrees.
	 */
	inline double radians_to_degrees(double radians) {
		return radians * (180.0 / M_PI);
	}
}

// -------------------------------------------------------------------------

// =========================================================================
// ## units
// Contains custom data types for unit-safety and convenience, like Percentage.
// =========================================================================
namespace units {
	/**
	 * @brief A type-safe representation of a percentage value (0.0 to 100.0).
	 * Clamps the value upon construction to ensure it is within the valid range.
	 */
	struct Percentage {
		/// @brief The percentage value (0.0 to 100.0).
		double value_perc;

		/**
		 * @brief Constructs a Percentage object. The input value is clamped between 0.0 and 100.0.
		 * @param value The raw percentage value.
		 */
		explicit Percentage(double value);

		/**
		 * @brief Applies the percentage to a base value.
		 * @param base The base value to apply the percentage to.
		 * @return The result of the calculation (base * percentage/100).
		 */
		double applyTo(double base) const;

		/// @brief Adds two percentage values. The result is clamped.
		Percentage operator+(const Percentage& other) const;

		/// @brief Multiplies a percentage value by a scalar. The result is clamped.
		Percentage operator*(double scalar) const;

		/// @brief Friend function to allow scalar multiplication from the left.
		friend Percentage operator*(double scalar, const Percentage& perc);
	};
} // namespace units

} // namespace util
} // namespace T_Lib

// =========================================================================
// ## Literal Operators ✍️
// Custom literal operators for easily creating 'Percentage' objects.
// These must be declared in the global scope or a top-level namespace.
// =========================================================================
namespace T_Lib::util::units::percentage_literals {

	/**
	 * @brief Creates a Percentage object from a floating point literal (e.g., `50.0_perc`).
	 */
	inline T_Lib::util::units::Percentage operator"" _perc(long double value) {
		return T_Lib::util::units::Percentage(static_cast<double>(value));
	}

	/**
	 * @brief Creates a Percentage object from an integer literal (e.g., `50_perc`).
	 */
	inline T_Lib::util::units::Percentage operator"" _perc(unsigned long long value) {
		return T_Lib::util::units::Percentage(static_cast<double>(value));
	}
}