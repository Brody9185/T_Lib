#pragma once

// Header-only declarations for T_Lib::T_Motor; implementations are in Motor.cpp

// --- PROS Library Includes ---
#include "pros/gps.h"
#include "pros/motors.hpp"
#include "pros/rtos.hpp"
#include "pros/misc.h"

// --- Standard Library ---
#include <atomic>

// Local util definitions (Aliases, helpers)
#include "T_Lib/util.hpp"

namespace T_Lib {

class T_Motor {
private:
	pros::Motor motor;
	pros::Task* control_task;

	std::atomic<double> target_rpm{0.0};
	std::atomic<bool> running{true};
	std::atomic<bool> reversed{false};

	double kV_low{0.0};
	double kP_low{0.0};
	double kI_low{0.0};
	double kD_low{0.0};
	double kV_high{0.0};
	double kP_high{0.0};
	double kI_high{0.0};
	double kD_high{0.0};
	double start_I{0.0};

	std::atomic<bool> load_comp_enabled{true};
	std::atomic<double> load_kBoost{4.5};
	std::atomic<int> load_threshold{15};

	std::atomic<bool> min_torque_enabled{true};
	std::atomic<int> min_voltage_user{1200};
	std::atomic<int> min_voltage{1200};
	int min_voltage_low{600};

	double base_rpm{600.0};

	std::atomic<bool> slew_enabled{false};
	std::atomic<double> max_slew_change{500.0};

	std::atomic<bool> pid_enabled{true};

	double integral_error{0.0};
	double last_error{0.0};

	void initBaseRPM(pros::v5::MotorGears gearset);
	static void controlLoopTask(void* param);

public:
	// Constructors / destructor
	T_Motor(int port, pros::v5::MotorGears gearset = util::Aliases::Blue, bool reversed = false);
	~T_Motor();

	T_Motor(const T_Motor& other);
	T_Motor& operator=(const T_Motor& other);

	// Control
	void setTargetRPM(double rpm);
	void setTargetPercent(double percent);
	void stop();

	// PID toggle
	void setPIDEnabled(bool enabled);
	bool isPIDEnabled() const;

	// Slew
	void setSlewLimitEnabled(bool enabled);
	bool isSlewLimitEnabled() const;
	void setSlewRate(double maxChange);
	double getSlewRate() const;

	// Sensors / status
	double getRPM() const;
	double getTargetRPM() const;
	double getTemperature() const;
	double getPosition() const;
	int getVoltage() const;
	bool isSpinning() const;
	bool isSpinningRaw() const;

	// Settings
	void resetPosition();
	void setBrakeMode(pros::v5::MotorBrake mode);

	void setLoadCompensation(bool enabled);
	void setLoadCompensation(bool enabled, double kBoost);
	void setLoadCompensation(bool enabled, double kBoost, int threshold);

	void setDualConstants(double kvLow, double kpLow, double kvHigh, double kpHigh);
	void setDualConstants(double kvLow, double kpLow, double kiLow, double kdLow, double kvHigh, double kpHigh, double kiHigh, double kdHigh);
	void setLowConstants(double kvLow, double kpLow);
	void setLowConstants(double kvLow, double kpLow, double kiLow, double kdLow);
	void setHighConstants(double kvHigh, double kpHigh);
	void setHighConstants(double kvHigh, double kpHigh, double kiHigh, double kdHigh);

	void setStartI(double startIntegral);

	void setMinTorque(bool enabled);
	void setMinTorque(bool enabled, int minMv);
	void setMinTorque(bool enabled, int minMv, int minLowMv);

	void setReversed(bool rev);
	bool isReversed() const;

	// Getters
	double getLowKV() const;
	double getLowKP() const;
	double getLowKI() const;
	double getLowKD() const;
	double getHighKV() const;
	double getHighKP() const;
	double getHighKI() const;
	double getHighKD() const;
	double getStartI() const;

	double getBaseRPM() const;
	int getVoltageLimit() const;
	pros::v5::MotorGears getGearset() const;

	bool isLoadCompEnabled() const;
	double getLoadKBoost() const;
	int getLoadThreshold() const;

	bool isMinTorqueEnabled() const;
	int getMinVoltageUser() const;
	int getMinVoltageLow() const;
	int getActiveMinVoltage() const;
};

} // namespace T_Lib